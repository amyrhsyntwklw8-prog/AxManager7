# AxElden Engine 15 — Main & Beta

## Included
- C++17 native library loaded as `libaxelden.so`, preserving the existing `AxOmniBridge.scanNative` JNI entry point.
- ARM NEON 128-bit (4 x float32) smoothing with a portable scalar fallback. A 200-bit SIMD ISA is not a standard Android ARM64 feature.
- Gyroscope low-pass filter primitives, input validation, bounded sensitivity values, and sample profile JSON for Rifle, SMG, Sniper, Shotgun, LMG, Marksman and Pistol.
- Device-safe color capability policy: does not force Adobe RGB, 10-bit or unsupported wide-gamut modes.
- Existing read-only live monitor, log rotation, scoped recovery and AxElden-only restart.

## Main vs Beta
- `main.json`: conservative defaults, max 2 worker threads, quiet diagnostics, experimental flags off.
- `beta.json`: expanded diagnostics and opt-in experimental flags, max 3 worker threads.
- Both use one worker by default and do not pin CPU cores.

## Important boundaries
Profiles are reference settings for manual use in game settings. The engine does not inject into games, read/write game memory, hook game functions, alter recoil/aim/FOV/ammo, bypass anti-cheat, or replace the game's own input pipeline. Gyroscope filtering becomes active only when AxManager supplies sensor samples through its own Android sensor integration; this package adds native math primitives, not an unverified in-game sensor override.

## Build
Open the project in Android Studio with Android NDK/CMake installed and build the `manager` module. The native target is `axelden` and outputs `libaxelden.so` for the configured ABI. A successful ZIP check does not mean an APK build or device test has been completed.

## Recovery
Use the module action script: `sh action.sh status`, `sh action.sh restart`, or `sh action.sh recover`. Recovery is scoped to AxElden runtime state and does not kill unrelated processes or change game settings.
