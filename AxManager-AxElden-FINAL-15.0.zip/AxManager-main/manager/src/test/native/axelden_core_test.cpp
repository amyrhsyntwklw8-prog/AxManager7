#include "../../main/cpp/axelden_core.h"
#include <cassert>
#include <cmath>
int main(){
  assert(std::fabs(axelden::lowPass(0.0f,10.0f,0.5f)-5.0f)<0.001f);
  assert(axelden::clampSensitivity(NAN)==100.0f);
  float p[4]={0,0,0,0},s[4]={4,8,12,16},o[4]={};
  axelden::smooth4(p,s,o,0.5f);
  assert(o[0]==2 && o[1]==4 && o[2]==6 && o[3]==8);
  auto g=axelden::filterGyro({0,0,0},{10,20,30},0.5f);
  assert(g.x==5 && g.y==10 && g.z==15);
}
