#include <jni.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>
#include "axelden_core.h"

// Bounded read-only diagnostic retained for AxOmniBridge compatibility.
// No process-memory access, process injection, core pinning, or game modification.
static jlong count_boot_marker(const char* path) {
    if (!path || !*path) return -1;
    std::ifstream in(path, std::ios::binary);
    if (!in) return -1;
    in.seekg(0, std::ios::end);
    const std::streamoff size = in.tellg();
    if (size < 0 || size > 64LL * 1024LL * 1024LL) return -2;
    in.seekg(0, std::ios::beg);
    std::string line;
    std::size_t hits = 0;
    while (std::getline(in, line)) {
        if (line.size() > 8192) continue;
        if (line == "boot_completed") ++hits;
    }
    return static_cast<jlong>(hits);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_axdubai_manager_core_AxOmniBridge_scanNative(
        JNIEnv* env, jobject /*thiz*/, jstring path, jint /*threads*/) {
    if (!path) return -1;
    const char* utf = env->GetStringUTFChars(path, nullptr);
    if (!utf) return -1;
    const jlong result = count_boot_marker(utf);
    env->ReleaseStringUTFChars(path, utf);
    return result;
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_axdubai_manager_core_AxEldenNativeBridge_filterGyro(
        JNIEnv*, jobject, jfloat previous, jfloat sample, jfloat alpha) {
    if (!std::isfinite(previous) || !std::isfinite(sample) || !std::isfinite(alpha)) return 0.0f;
    return axelden::lowPass(previous, sample, alpha);
}
