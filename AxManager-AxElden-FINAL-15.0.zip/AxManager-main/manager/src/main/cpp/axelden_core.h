#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
#include <arm_neon.h>
#endif

namespace axelden {
constexpr float kMinAlpha = 0.01f;
constexpr float kMaxAlpha = 0.99f;
inline float clampAlpha(float a) noexcept {
    if (!std::isfinite(a)) return 0.18f;
    return std::max(kMinAlpha, std::min(kMaxAlpha, a));
}
inline float lowPass(float previous, float sample, float alpha) noexcept {
    if (!std::isfinite(previous) || !std::isfinite(sample)) return 0.0f;
    const float a = clampAlpha(alpha);
    return previous + a * (sample - previous);
}
// 4-lane float smoothing. ARM64 uses 128-bit NEON; other targets use scalar fallback.
inline void smooth4(const float* previous, const float* sample, float* output, float alpha) noexcept {
    if (!previous || !sample || !output) return;
    const float a = clampAlpha(alpha);
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
    const float32x4_t pv = vld1q_f32(previous);
    const float32x4_t sv = vld1q_f32(sample);
    const float32x4_t av = vdupq_n_f32(a);
    const float32x4_t ov = vmlaq_f32(pv, vsubq_f32(sv, pv), av);
    vst1q_f32(output, ov);
#else
    for (std::size_t i=0; i<4; ++i) output[i] = lowPass(previous[i], sample[i], a);
#endif
    for (std::size_t i=0; i<4; ++i) if (!std::isfinite(output[i])) output[i]=0.0f;
}
inline float clampSensitivity(float v, float minV=1.0f, float maxV=300.0f) noexcept {
    if (!std::isfinite(v)) return 100.0f;
    return std::max(minV, std::min(maxV, v));
}
struct GyroSample { float x, y, z; };
inline GyroSample filterGyro(const GyroSample& prev, const GyroSample& now, float alpha) noexcept {
    return {lowPass(prev.x,now.x,alpha), lowPass(prev.y,now.y,alpha), lowPass(prev.z,now.z,alpha)};
}
}
