# AxElden Live Monitor v14 — Resilience Edition

## Purpose
An Android-side companion monitor. It samples foreground-app identity, battery
percentage and best-effort thermal telemetry every five seconds. It does not
run inside Call of Duty Mobile and does not modify game data or memory.

## Reliability improvements
- Atomic status-file replacement and bounded two-generation service logs.
- Duplicate-instance check with PID command-line identity verification.
- Bounded boot-completion wait and bounded status-write failure handling.
- Recovery only removes AxElden runtime files and only signals a process after
  verifying its command line.
- Restart waits for the new service PID instead of assuming startup succeeded.
- `action.sh status`, `action.sh restart`, and `action.sh recover` commands.

## Package detection
The default package ID is listed in `game-packages.txt`. Add exact regional
package IDs one per line. Detection reports foreground status only.

## Safety boundaries
No injection, game-memory access, hooks, FOV changes, game-file edits,
anti-cheat bypass, CPU/GPU overclocking, or thermal-policy overrides.
Temperature readings are best-effort and device-vendor dependent. A five-second
polling interval is not instantaneous. Recovery does not reboot Android and
does not reset unrelated system settings.
