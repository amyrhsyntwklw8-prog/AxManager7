#!/system/bin/sh
# Restart only AxElden's companion monitor.
MODDIR=${0%/*}
STATE_DIR=/data/adb/axelden
mkdir -p "$STATE_DIR" 2>/dev/null || exit 1
rm -f "$MODDIR/disable"
sh "$MODDIR/recovery.sh" || exit 1
nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
N=0
while [ "$N" -lt 8 ]; do
    if [ -r "$STATE_DIR/service.pid" ]; then
        PID=$(cat "$STATE_DIR/service.pid" 2>/dev/null)
        case "$PID" in ''|*[!0-9]*) PID= ;; *)
            if kill -0 "$PID" 2>/dev/null; then exit 0; fi ;;
        esac
    fi
    N=$((N+1))
    sleep 1
done
exit 1
