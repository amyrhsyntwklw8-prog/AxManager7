#!/system/bin/sh
MODDIR=${0%/*}
STATE_DIR=/data/adb/axelden
STATUS="$STATE_DIR/status.txt"
LOG="$STATE_DIR/service.log"
case "$1" in
    restart)
        exec sh "$MODDIR/restart.sh"
        ;;
    recover)
        exec sh "$MODDIR/recovery.sh"
        ;;
    status|"")
        if [ -f "$MODDIR/disable" ]; then
            echo "AxElden is disabled."
        elif [ -r "$STATUS" ]; then
            cat "$STATUS"
        else
            echo "AxElden monitor is not currently reporting status."
            [ -r "$LOG" ] && tail -n 12 "$LOG"
        fi
        echo "Commands: action.sh status | restart | recover"
        ;;
    *)
        echo "Usage: sh action.sh [status|restart|recover]"
        exit 2
        ;;
esac
