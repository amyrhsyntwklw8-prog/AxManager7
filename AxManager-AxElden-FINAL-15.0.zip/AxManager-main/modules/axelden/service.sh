#!/system/bin/sh
# AxElden Live Monitor v14 - resilient, read-only companion monitor.
MODDIR=${0%/*}
STATE_DIR=/data/adb/axelden
LOG="$STATE_DIR/service.log"
OLD_LOG="$STATE_DIR/service.log.1"
PIDFILE="$STATE_DIR/service.pid"
STATUS="$STATE_DIR/status.txt"
GAME_LIST="$MODDIR/game-packages.txt"
INTERVAL=5
MAX_LOG_BYTES=65536
MAX_RETRIES=3

umask 077
mkdir -p "$STATE_DIR" 2>/dev/null || exit 1
[ -f "$MODDIR/disable" ] && exit 0
[ -f "$MODDIR/remove" ] && exit 0

log() {
    SIZE=0
    [ -f "$LOG" ] && SIZE=$(wc -c < "$LOG" 2>/dev/null)
    case "$SIZE" in ''|*[!0-9]*) SIZE=0 ;; esac
    if [ "$SIZE" -ge "$MAX_LOG_BYTES" ]; then
        rm -f "$OLD_LOG"
        mv "$LOG" "$OLD_LOG" 2>/dev/null
    fi
    echo "[$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)] $*" >> "$LOG"
}

is_our_service() {
    P=$1
    [ -n "$P" ] && [ -r "/proc/$P/cmdline" ] || return 1
    CMD=$(tr '\000' ' ' < "/proc/$P/cmdline" 2>/dev/null)
    case "$CMD" in *"axelden/service.sh"*|*"$MODDIR/service.sh"*) return 0 ;; esac
    return 1
}

# Refuse duplicate instances; never signal a process unless its identity matches.
if [ -r "$PIDFILE" ]; then
    OLD_PID=$(cat "$PIDFILE" 2>/dev/null)
    case "$OLD_PID" in ''|*[!0-9]*) OLD_PID= ;; esac
    if [ -n "$OLD_PID" ] && [ "$OLD_PID" != "$$" ] &&
       kill -0 "$OLD_PID" 2>/dev/null && is_our_service "$OLD_PID"; then
        exit 0
    fi
fi
TMP_PID="$PIDFILE.$$"
echo "$$" > "$TMP_PID" 2>/dev/null || exit 1
mv "$TMP_PID" "$PIDFILE" 2>/dev/null || exit 1

read_max_temp_c() {
    MAX=0
    for F in /sys/class/thermal/thermal_zone*/temp; do
        [ -r "$F" ] || continue
        V=$(cat "$F" 2>/dev/null)
        case "$V" in ''|*[!0-9-]*) continue ;; esac
        [ "$V" -lt 0 ] 2>/dev/null && continue
        # Most Android sensors report millidegrees; small values are already °C.
        if [ "$V" -ge 10000 ] 2>/dev/null; then C=$((V / 1000))
        elif [ "$V" -ge 1000 ] 2>/dev/null; then C=$((V / 100))
        else C=$V
        fi
        [ "$C" -gt "$MAX" ] && MAX=$C
    done
    echo "$MAX"
}

get_foreground_package() {
    APP=$(dumpsys activity activities 2>/dev/null |
        grep -m 1 -E 'mResumedActivity|topResumedActivity' |
        sed -n 's/.* u[0-9][0-9]* \([^ ]*\).*/\1/p' | cut -d/ -f1)
    if [ -z "$APP" ]; then
        APP=$(dumpsys window 2>/dev/null |
            grep -m 1 -E 'mCurrentFocus|mFocusedApp' |
            sed -n 's/.* u[0-9][0-9]* \([^ ]*\).*/\1/p' | cut -d/ -f1)
    fi
    [ -n "$APP" ] || APP=unknown
    echo "$APP"
}

is_game_package() {
    TARGET=$1
    [ -n "$TARGET" ] && [ -r "$GAME_LIST" ] || return 1
    while IFS= read -r PKG; do
        case "$PKG" in ''|\#*) continue ;; esac
        [ "$TARGET" = "$PKG" ] && return 0
    done < "$GAME_LIST"
    return 1
}

write_status() {
    TEMP_C=$1 BAT=$2 APP=$3 THERMAL=$4 ACTIVE=$5
    TMP_STATUS="$STATUS.$$"
    {
        echo "schema=2"
        echo "state=running"
        echo "temperature_c=$TEMP_C"
        echo "thermal_state=$THERMAL"
        echo "battery_percent=$BAT"
        echo "foreground_package=$APP"
        echo "game_active=$ACTIVE"
        echo "updated_at=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
        echo "mode=read_only_live_monitor"
        echo "interval_seconds=$INTERVAL"
    } > "$TMP_STATUS" && mv "$TMP_STATUS" "$STATUS"
}

cleanup() {
    CURRENT=$(cat "$PIDFILE" 2>/dev/null)
    [ "$CURRENT" = "$$" ] && rm -f "$PIDFILE"
    rm -f "$STATUS.$$" "$PIDFILE.$$"
    log "monitor stopped"
}
trap 'cleanup; exit 0' INT TERM HUP
trap cleanup EXIT

N=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0
    N=$((N+1))
    [ "$N" -gt 90 ] && { log "boot wait timed out"; exit 1; }
    sleep 2
done

log "v14 monitor started; interval=${INTERVAL}s"
PREV_GAME=unknown
FAILS=0
while :; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0

    TEMP_C=$(read_max_temp_c)
    BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
    case "$BAT" in ''|*[!0-9]*) BAT=unknown ;; esac
    APP=$(get_foreground_package)
    [ -n "$APP" ] || APP=unknown

    if is_game_package "$APP"; then ACTIVE=true; else ACTIVE=false; fi
    if [ "$TEMP_C" -ge 45 ] 2>/dev/null; then THERMAL=hot
    elif [ "$TEMP_C" -ge 40 ] 2>/dev/null; then THERMAL=warm
    else THERMAL=normal
    fi

    if [ "$ACTIVE" != "$PREV_GAME" ]; then
        log "foreground transition: game_active=$ACTIVE package=$APP"
        PREV_GAME=$ACTIVE
    fi
    if write_status "$TEMP_C" "$BAT" "$APP" "$THERMAL" "$ACTIVE"; then
        FAILS=0
    else
        FAILS=$((FAILS+1))
        log "warning: status update failed ($FAILS/$MAX_RETRIES)"
        [ "$FAILS" -ge "$MAX_RETRIES" ] && { log "status failures exceeded; stopping safely"; exit 1; }
    fi
    sleep "$INTERVAL"
done
