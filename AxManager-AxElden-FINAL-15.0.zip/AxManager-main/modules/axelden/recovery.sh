#!/system/bin/sh
# Clear only AxElden runtime state. No game or Android tuning settings are touched.
STATE_DIR=/data/adb/axelden
PIDFILE="$STATE_DIR/service.pid"
STATUS="$STATE_DIR/status.txt"
LOG="$STATE_DIR/recovery.log"
umask 077
mkdir -p "$STATE_DIR" 2>/dev/null || exit 1

if [ -r "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE" 2>/dev/null)
    case "$PID" in ''|*[!0-9]*) PID= ;; esac
    if [ -n "$PID" ] && [ "$PID" != "$$" ] && kill -0 "$PID" 2>/dev/null; then
        CMD=$(tr '\000' ' ' < "/proc/$PID/cmdline" 2>/dev/null)
        case "$CMD" in
            *"axelden/service.sh"*)
                kill -TERM "$PID" 2>/dev/null || true
                N=0
                while [ "$N" -lt 10 ] && kill -0 "$PID" 2>/dev/null; do sleep 1; N=$((N+1)); done
                if kill -0 "$PID" 2>/dev/null; then
                    echo "Recovery: monitor did not stop within timeout; no force-kill attempted." >> "$LOG"
                fi
                ;;
            *) echo "Recovery: PID identity mismatch; unrelated process left untouched." >> "$LOG" ;;
        esac
    fi
fi
rm -f "$PIDFILE" "$STATUS" "$STATUS.tmp" "$PIDFILE".* "$STATUS".*
echo "[$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)] Recovery completed; AxElden runtime state cleared only." >> "$LOG"
exit 0
