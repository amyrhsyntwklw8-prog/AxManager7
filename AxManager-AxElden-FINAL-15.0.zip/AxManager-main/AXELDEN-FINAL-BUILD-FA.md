# راهنمای نسخه نهایی AxElden Main 15.0

## انتخاب نسخه
این بسته بر پایه پروفایل **Main** است؛ برای استفاده عادی همین نسخه را انتخاب کنید. فایل `modules/axelden/profiles/beta.json` فقط پروفایل آزمایشی است و به‌صورت پیش‌فرض فعال نیست.

## قبل از جایگزینی
1. از کل پروژه و فایل‌های امضای APK خود نسخه پشتیبان بگیرید.
2. پروژه را در Android Studio ببندید.
3. فایل ZIP را در یک پوشه جدا استخراج کنید؛ روی پروژه اصلی مستقیماً Extract نکنید.

## جایگزینی در سورس موجود
ریشه پروژه را `AxManager-main/` در نظر بگیرید. فایل‌ها را با حفظ همین مسیرها در پروژه خود کپی و در صورت درخواست، فقط فایل‌های هم‌نام را جایگزین کنید:

- `manager/src/main/cpp/axelden_engine.cpp`
- `manager/src/main/cpp/axelden_core.h`
- `manager/src/main/cpp/CMakeLists.txt`  (این فایل را کامل جایگزین کنید تا target مربوط به `axelden` ثبت شود؛ اگر CMake خودتان تغییرات دیگری دارد، فقط بخش target مربوط به AxElden را ادغام کنید.)
- `manager/src/main/java/frb/axeron/manager/core/AxOmniBridge.java`
- کل پوشه `modules/axelden/`

پوشه `modules/axelden/` یک افزونه مستقل AxManager است. برای نصب آن از رابط Plugins، از فایل جداگانه `AxElden-Module-Main-15.0.zip` استفاده کنید؛ لازم نیست ZIP کامل سورس را به‌عنوان افزونه نصب کنید.

## پیش‌نیازهای Build
- Android Studio و JDK 21
- Android SDK Platform 36 و Build Tools 36.0.0
- Android NDK نسخه `29.0.14206865`
- CMake نسخه `3.22.1` یا جدیدتر سازگار
- Git و اتصال اینترنت برای دریافت وابستگی‌های Gradle

**مهم درباره ZIP سورس:** مخزن اصلی یک Git submodule به نام `api` دارد. ZIP سورس به‌تنهایی پوشه submodule و تاریخچه Git را ندارد؛ بنابراین ممکن است مستقیم Build نشود. روش مطمئن این است که مخزن خودتان را با submoduleها Clone کنید و سپس فایل‌های بالا را روی آن جایگزین کنید:

```bash
git clone --recurse-submodules https://github.com/amyrhsyntwklw8-prog/AxManager.git
cd AxManager
```

اگر پروژه را از قبل Clone کرده‌اید:

```bash
git submodule update --init --recursive
```

بعد از کپی فایل‌ها، پروژه را در Android Studio باز کنید، اجازه دهید Gradle Sync کامل شود و NDK/CMake خواسته‌شده را از SDK Manager نصب کنید.

## ساخت APK
در ترمینال ریشه پروژه:

```bash
./gradlew :manager:assembleDebug
```

در ویندوز:

```bat
gradlew.bat :manager:assembleDebug
```

برای Release:

```bash
./gradlew :manager:assembleRelease
```

Release به کلید امضای معتبر پروژه نیاز دارد. مقادیر `signing.storeFile`، `signing.storePassword`، `signing.keyAlias` و `signing.keyPassword` را در `local.properties` مطابق keystore خودتان تنظیم کنید. فایل keystore و رمز آن را در ZIP یا Git قرار ندهید.

APK خروجی معمولاً زیر این مسیر ساخته می‌شود:

`manager/build/outputs/apk/`

نام نهایی فایل ممکن است با نسخه و زمان Build تغییر کند.

## بررسی و بازیابی
- پروفایل پیش‌فرض: `modules/axelden/profiles/main.json`
- پروفایل آزمایشی: `modules/axelden/profiles/beta.json`
- وضعیت سرویس: اجرای `sh action.sh status` از پوشه افزونه
- راه‌اندازی مجدد فقط سرویس AxElden: `sh action.sh restart`
- بازیابی فایل‌های runtime خود AxElden: `sh action.sh recover`

قبل از فعال‌کردن افزونه، مطمئن شوید نسخه پشتیبان دارید. Recovery فقط state مربوط به AxElden را هدف می‌گیرد؛ با این حال روی دستگاه اصلی ابتدا با احتیاط آزمایش کنید.

## محدوده عملکرد و آزمون
این نسخه شامل C++17، ARM NEON 128-bit با مسیر جایگزین scalar، فیلتر ریاضی ژیروسکوپ، اعتبارسنجی ورودی و پروفایل‌های مرجع حساسیت است. SIMD روی CPU اجرا می‌شود و «۲۰۰ بیت» یک ISA استاندارد ARM64 نیست. فیلتر ژیروسکوپ در این بسته primitive پردازشی است؛ برای دریافت داده سنسور باید لایه Android SensorManager در خود AxManager آن را فراخوانی کند.

پروفایل‌ها فقط مقادیر مرجع برای واردکردن دستی در تنظیمات پشتیبانی‌شده بازی هستند. این پروژه به فرایند بازی تزریق نمی‌کند، حافظه یا توابع بازی را Hook نمی‌کند، Aim/Recoil/FOV/Ammo را تغییر نمی‌دهد و ضدتقلب را دور نمی‌زند. رنگ و gamut نیز فقط در محدوده پشتیبانی واقعی نمایشگر و Android قابل مدیریت است.

## وضعیت اعتبارسنجی این بسته
- ساختار ZIP و CRC فایل‌ها بررسی شده است.
- تست واحد هسته C++ با کامپایلر میزبان اجرا شده است.
- بررسی نحوی اسکریپت‌های shell با `sh -n` موفق بوده است.
- APK اندروید در این محیط ساخته یا روی گوشی آزمایش نشده است؛ پس پس از Gradle Sync، Build و نصب آزمایشی را خودتان تأیید کنید.
